
import React, { useState, useCallback, useEffect } from 'react';
import RetroLayout from './components/RetroLayout';
import ModernLayout from './components/ModernLayout';

const App: React.FC = () => {
  const [isModern, setIsModern] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const handleExecute = useCallback(() => {
    setIsTransitioning(true);
    // Simulate a system upgrade delay
    setTimeout(() => {
      setIsModern(true);
      setIsTransitioning(false);
    }, 1500);
  }, []);

  return (
    <div className="min-h-screen">
      {isTransitioning && (
        <div className="fixed inset-0 z-50 bg-white animate-pulse flex items-center justify-center">
          <div className="text-black font-bold text-4xl uppercase tracking-widest animate-bounce">
            Upgrading Architecture...
          </div>
        </div>
      )}
      
      {!isModern ? (
        <RetroLayout onExecute={handleExecute} />
      ) : (
        <ModernLayout />
      )}
    </div>
  );
};

export default App;
