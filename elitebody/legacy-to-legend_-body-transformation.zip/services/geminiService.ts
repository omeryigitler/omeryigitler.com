
import { GoogleGenAI } from "@google/genai";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export const generatePlan = async (age: number, weight: number, goal: string) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Design a fitness 'architecture' for an ${age}-year-old individual weighing ${weight}kg with the goal of ${goal}. Use coding and software development terminology. Provide status, modules, and nutrition dependencies.`,
  });
  return response.text;
};
