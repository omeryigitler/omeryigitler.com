
import React from 'react';

interface RetroLayoutProps {
  onExecute: () => void;
}

const RetroLayout: React.FC<RetroLayoutProps> = ({ onExecute }) => {
  return (
    <div className="bg-[#c0c0c0] min-h-screen text-black pixel-font flex flex-col items-center p-4">
      {/* Header Bar */}
      <div className="w-full max-w-4xl bg-blue-900 text-white p-2 retro-border flex justify-between items-center mb-8">
        <span className="text-xs sm:text-sm">LEGACY_BODY_v1.0.exe</span>
        <div className="flex gap-1">
          <div className="w-4 h-4 bg-[#c0c0c0] retro-border"></div>
          <div className="w-4 h-4 bg-[#c0c0c0] retro-border"></div>
          <div className="w-4 h-4 bg-[#c0c0c0] retro-border text-black flex items-center justify-center text-[10px]">X</div>
        </div>
      </div>

      {/* Main Content Table-like structure */}
      <div className="w-full max-w-4xl bg-[#c0c0c0] p-6 retro-border shadow-2xl space-y-8">
        <div className="text-center">
          <h1 className="text-2xl sm:text-4xl font-bold mb-4 drop-shadow-lg text-blue-800">
            SYSTEM_REBUILD: ATHLETE
          </h1>
          <div className="h-1 bg-black w-full mb-2"></div>
          <div className="marquee-container bg-black text-green-500 py-1 text-xs">
            <span className="marquee-text">
              ::: INITIALIZING BODY COMPILATION ::: OPTIMIZING MUSCLE KERNEL ::: DEFRAGGING FAT STORAGE ::: READY TO EXECUTE :::
            </span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="retro-inset bg-black p-4 space-y-4">
            <p className="text-green-500 text-xs leading-relaxed">
              &gt; User detected.<br/>
              &gt; Status: UNOPTIMIZED.<br/>
              &gt; Physical architecture outdated.<br/>
              &gt; Processing potential...<br/>
              &gt; [SUCCESS] High capacity found.
            </p>
            <div className="flex justify-center">
              <img 
                src="https://picsum.photos/seed/retro-fit/300/200" 
                alt="Retro Gym" 
                className="grayscale contrast-125 border-2 border-green-500 w-full object-cover"
              />
            </div>
          </div>

          <div className="flex flex-col justify-center space-y-6 text-center">
            <p className="text-sm leading-8">
              "Build your body like you build code."
            </p>
            <p className="text-[10px] text-gray-600">
              Optimal performance requires a total system rewrite. Stop running legacy hardware.
            </p>
            
            <button 
              onClick={onExecute}
              className="bg-red-600 hover:bg-red-700 text-white p-8 retro-border text-xl sm:text-2xl shadow-xl transition-all transform active:scale-95 group relative overflow-hidden"
            >
              <span className="relative z-10">EXECUTE TRANSFORMATION</span>
              <div className="absolute inset-0 bg-yellow-400 opacity-0 group-hover:opacity-20"></div>
            </button>
            
            <p className="text-[10px] blink text-red-600 font-bold uppercase">
              Warning: Permanent hardware changes ahead
            </p>
          </div>
        </div>

        {/* Footer info */}
        <div className="flex flex-col sm:flex-row justify-between items-center pt-8 gap-4">
          <div className="flex items-center gap-2">
            <span className="text-[10px]">VISITOR COUNT:</span>
            <div className="bg-black text-white px-2 py-1 text-xs border border-white">
              000,421,08
            </div>
          </div>
          <div className="text-[8px] text-center sm:text-right">
            Best viewed in 800x600 resolution.<br/>
            Copyright &copy; 1998 TRANSFORMATION LABS.
          </div>
        </div>
      </div>

      <div className="mt-8 text-[10px] text-gray-500">
        [ Powered by CyberPhysique Network ]
      </div>
    </div>
  );
};

export default RetroLayout;
