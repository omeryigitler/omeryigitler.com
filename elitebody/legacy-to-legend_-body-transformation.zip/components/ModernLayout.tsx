
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Type } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const ModernLayout: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState<string | null>(null);
  const [stats, setStats] = useState({ age: 30, weight: 80, goal: 'Hypertrophy' });

  const analyzeArchitecture = async () => {
    setLoading(true);
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `You are the 'Elite Transformation OS'. Analyze this physical architecture: Age: ${stats.age}, Weight: ${stats.weight}kg, Goal: ${stats.goal}. 
        Provide a response in Markdown with:
        1. A technical 'Kernel Audit' (Current Status)
        2. 'Module Upgrades' (Workout structure)
        3. 'Dependency Injection' (Nutrition)
        Keep the tone professional, technical, and high-performance. Use coding metaphors.`,
        config: {
          temperature: 0.8,
        }
      });
      setOutput(response.text || "Analysis failed. Please reboot system.");
    } catch (error) {
      console.error(error);
      setOutput("CONNECTION ERROR: API_KEY_MISMATCH");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-neutral-950 min-h-screen text-white modern-font p-6 md:p-12 animate-in fade-in duration-1000">
      {/* Navbar */}
      <nav className="flex justify-between items-center mb-16 max-w-7xl mx-auto">
        <div className="text-2xl font-black tracking-tighter italic">V2.0_ELITE</div>
        <div className="hidden md:flex gap-8 text-sm font-medium tracking-widest text-neutral-400 uppercase">
          <a href="#" className="hover:text-white transition-colors">Training</a>
          <a href="#" className="hover:text-white transition-colors">Fuel</a>
          <a href="#" className="hover:text-white transition-colors">Logic</a>
          <a href="#" className="hover:text-white transition-colors">Account</a>
        </div>
      </nav>

      {/* Main Grid */}
      <main className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12">
        {/* Left Column: Vision & Identity */}
        <div className="space-y-8">
          <div className="space-y-2">
            <h2 className="text-blue-500 font-bold uppercase tracking-[0.3em] text-sm">Upgrade Confirmed</h2>
            <h1 className="text-5xl md:text-7xl font-black leading-tight">
              YOUR PAGE HAS <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-cyan-400">CHANGED.</span>
            </h1>
            <p className="text-xl text-neutral-400 max-w-md leading-relaxed">
              The legacy code is gone. Now, we rebuild your physical framework from the ground up.
            </p>
          </div>

          <div className="p-8 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-6">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
              Optimization Console
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Weight (kg)</label>
                <input 
                  type="number" 
                  value={stats.weight} 
                  onChange={(e) => setStats({...stats, weight: parseInt(e.target.value) || 0})}
                  className="w-full bg-black border border-neutral-800 p-3 rounded-lg focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Age</label>
                <input 
                  type="number" 
                  value={stats.age} 
                  onChange={(e) => setStats({...stats, age: parseInt(e.target.value) || 0})}
                  className="w-full bg-black border border-neutral-800 p-3 rounded-lg focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Objective</label>
              <select 
                value={stats.goal}
                onChange={(e) => setStats({...stats, goal: e.target.value})}
                className="w-full bg-black border border-neutral-800 p-3 rounded-lg focus:outline-none focus:border-blue-500 transition-colors"
              >
                <option>Hypertrophy</option>
                <option>Fat Loss</option>
                <option>Powerlifting</option>
                <option>Longevity</option>
              </select>
            </div>

            <button 
              onClick={analyzeArchitecture}
              disabled={loading}
              className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-black rounded-xl transition-all shadow-lg shadow-blue-900/20 active:scale-95 flex items-center justify-center gap-3"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ANALYZING...
                </>
              ) : 'COMPILE NEW BUILD'}
            </button>
          </div>
        </div>

        {/* Right Column: Output & Visualization */}
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-1000"></div>
          <div className="relative h-full bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden flex flex-col">
            <div className="bg-neutral-800/50 p-4 border-b border-neutral-800 flex justify-between items-center">
              <span className="mono-font text-xs text-blue-400">transformation_log.md</span>
              <div className="flex gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              </div>
            </div>
            
            <div className="p-8 flex-1 overflow-y-auto mono-font text-sm text-neutral-300 space-y-4">
              {output ? (
                <div className="prose prose-invert max-w-none prose-blue">
                  {output.split('\n').map((line, i) => (
                    <p key={i} className={line.startsWith('#') ? 'text-blue-400 font-bold text-lg' : ''}>
                      {line}
                    </p>
                  ))}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center opacity-40 text-center space-y-4">
                  <div className="text-6xl">⚡</div>
                  <p>Awaiting architecture analysis...<br/>Run 'COMPILE NEW BUILD' to initiate.</p>
                </div>
              )}
            </div>

            <div className="p-4 bg-neutral-950/50 border-t border-neutral-800">
              <p className="text-[10px] uppercase tracking-widest text-neutral-500 text-center">
                &copy; 2025 ELITE_CORE // ALL SYSTEMS NOMINAL
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="max-w-7xl mx-auto mt-20 pt-10 border-t border-neutral-900 flex flex-col md:flex-row justify-between items-center gap-4 text-neutral-500 text-sm">
        <p>After this program, your body will have changed as much as this website did.</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-white transition-colors">Privacy</a>
          <a href="#" className="hover:text-white transition-colors">Security</a>
          <a href="#" className="hover:text-white transition-colors">Support</a>
        </div>
      </footer>
    </div>
  );
};

export default ModernLayout;
